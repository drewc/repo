/* File: "mylib.h", Time-stamp: <2007-04-04 14:30:31 feeley> */

/* Copyright (c) 2005-2007 by Marc Feeley, All Rights Reserved. */

___SCMOBJ new_counter ___PVOID;

void release_counter ___P((___SCMOBJ counter),());

void increment_counter ___P((___SCMOBJ counter),());

int get_counter ___P((___SCMOBJ counter),());
