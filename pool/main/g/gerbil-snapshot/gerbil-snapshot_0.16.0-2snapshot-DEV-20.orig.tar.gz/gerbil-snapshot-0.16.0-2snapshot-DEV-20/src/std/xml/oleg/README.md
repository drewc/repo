This is Oleg's Scheme XML package, cherry-picked ported to Gerbil.
See http://okmij.org/ftp/Scheme/xml.html

The code is in the public domain.
